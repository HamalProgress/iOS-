//
//  main.m
//  iOS蓝牙连接
//
//  Created by Charlie on 2017/8/16.
//  Copyright © 2017年 as. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
