//
//  AppDelegate.h
//  iOS蓝牙连接
//
//  Created by Charlie on 2017/8/16.
//  Copyright © 2017年 as. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

